enum vctrs_class_type class_type(r_obj* x);

static
enum vctrs_class_type class_type_impl(r_obj* cls);
