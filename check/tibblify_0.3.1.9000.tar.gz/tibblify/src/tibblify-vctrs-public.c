#include <vctrs.c>

// obj_is_vector
// short_vec_size
// short_vec_recycle
void tibblify_initialize_vctrs_public(void) {
  vctrs_init_api();
}
