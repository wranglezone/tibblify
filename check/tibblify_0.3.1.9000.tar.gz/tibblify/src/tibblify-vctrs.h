#ifndef TIBBLIFY_VCTRS_H
#define TIBBLIFY_VCTRS_H

#include "tibblify-vctrs-public.h"
#include "tibblify-vctrs-private.h"

#endif
