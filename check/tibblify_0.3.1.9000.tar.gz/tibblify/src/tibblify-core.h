// oriented on https://github.com/r-lib/vctrs/blob/e88a3e28822fa5bf925048e6bd0b10315f7bd9af/src/vctrs-core.h

#ifndef TIBBLIFY_CORE_H
#define TIBBLIFY_CORE_H

#include <rlang.h>
#include "globals.h"
#include "vctrs-type-info.h"

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#endif
