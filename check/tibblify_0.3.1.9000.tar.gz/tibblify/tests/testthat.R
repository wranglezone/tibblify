library(testthat)
library(tibblify)

test_check("tibblify")
