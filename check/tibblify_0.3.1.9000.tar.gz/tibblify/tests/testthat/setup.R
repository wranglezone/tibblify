pre_test_options <- options(
  tibblify.show_unspecified = FALSE,
  tibblify.print_names = FALSE
)
