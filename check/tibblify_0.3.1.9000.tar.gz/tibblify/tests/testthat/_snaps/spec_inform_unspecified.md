# informing about unspecified looks good

    Code
      spec_inform_unspecified(spec)
    Message
      The spec contains 6 unspecified fields:
      * 1un
      * 1df->2un
      * 1df->2row->3un
      * 1df->2row->3un2
      * 1row->2un2
      * 1row->2un3

